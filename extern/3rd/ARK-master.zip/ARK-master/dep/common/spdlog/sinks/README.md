# spdlog custom sinks

- date_and_hour_file_sink, rotate by hour, put the log into date directory, like: `log/20190710/test_14.log`
- rotating_file_with_date_sink, rotate by file size, put the log into date directory, like: `log/20190710/test.1.log`