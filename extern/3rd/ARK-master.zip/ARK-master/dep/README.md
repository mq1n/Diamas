# Dependencies

| lib             | branch | version |
| --------------- | ------ | ------- |
| google protobuf | 3.8.x  | 3.8.0   |
| brynet          | master |         |
| rapidxml        | master |         |
| args            | master |         |
| spdlog          | v1.x   | v1.3.0  |