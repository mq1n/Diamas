#include "base/AFPlatform.hpp"

#ifdef ARK_PLATFORMi_WIN

#pragma comment(lib, "Dbghelp.lib")
#pragma comment(lib, "ws2_32")

//#if ARK_RUN_MODE == ARK_RUN_MODE_DEBUG
//
//#pragma comment(lib, "brynetd.lib")
//#pragma comment(lib, "libprotobuf-lited.lib")
//#pragma comment(lib, "libprotobufd.lib")
//#pragma comment(lib, "AFProto_d.lib")
//
//#else
//
//#pragma comment(lib, "brynet.lib")
//#pragma comment(lib, "libprotobuf-lite.lib")
//#pragma comment(lib, "libprotobuf.lib")
//#pragma comment(lib, "AFProto.lib")
//
//#endif

#endif
