#include "interface/AFIPlugin.hpp"
#include "base/AFPluginManager.hpp"

namespace ark {

ARK_DECLARE_PLUGIN(AFConsulPlugin)

} // namespace ark
