### Fixes **OR** Add new function

#### Change propose:
- 
- 
- 
- 

> **Some notes:**  
> 	I change it for ...