//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by windows_example.rc
//
#define IDR_MENU1                       101
#define IDI_ICON1                       102
#define IDR_ACCELERATOR1                103
#define IDD_DIALOG_FILTER               104
#define IDC_FILTER_EDIT                 1001
#define IDC_FILTER_DESC_TEXT            1002
#define ID_FILE_OPEN40001               40001
#define ID_FILE_OPENURL                 40002
#define ID_FILE_SAVE40003               40003
#define ID_FILE_IMAGEPROPERTIES         40004
#define ID_FILE_PRINT40005              40005
#define ID_FILE_EXIT                    40006
#define ID_EDIT_UNDO40007               40007
#define ID_EDIT_UNDOLEVEL               40008
#define ID_EDIT_COOPY                   40009
#define ID_EDIT_PASTE40010              40010
#define ID_EDIT_VIEWMIPMAP              40011
#define ID_EDIT_VIEWIMAGENUMBER         40012
#define ID_EDIT_NEXTIMAGE               40013
#define ID_EDIT_C                       40014
#define ID_CONVERT_COLORINDEXED         40015
#define ID_CONVERT_LUMINANCE            40016
#define ID_CONVERT_LUMINANCEALPHA       40017
#define ID_CONVERT_RGB                  40018
#define ID_CONVERT_RGBA                 40019
#define ID_CONVERT_BGR                  40020
#define ID_CONVERT_BGRA                 40021
#define ID_CONVERT_ALLPHA               40022
#define ID_CONVERT_BATCHCONVERT         40023
#define ID_CONVERT_UNSIGNEDBYTE         40024
#define ID_CONVERT_UNSIGNEDBYTE40025    40025
#define ID_CONVERT_UNSIGNEDSHORT        40026
#define ID_CONVERT_FLOAT                40027
#define ID_CONVERT_DOUBLE               40028
#define ID_CONVERT_HALF                 40029
#define ID_HELP_ABOUT                   40030
#define ID_TOOLS_COUNTCOLORS            40031
#define ID_TOOLS_BACKGROUNDCOLOR        40032
#define ID_TOOLS_FILTERS                40033
#define ID_TOOLS_FLIP                   40034
#define ID_TOOLS_MIRROR                 40035
#define ID_TOOLS_ROTATE                 40036
#define ID_TOOLS_SCALE                  40037
#define ID_TOOLS_SCALEBOX               40038
#define ID_FILTERS_ALIENIFY             40039
#define ID_FILTERS_APPLYWAVE            40040
#define ID_FILTERS_BLUR                 40041
#define ID_FILTERS_EDGEDETECT           40042
#define ID_FILTERS_EMBOSS               40043
#define ID_FILTERS_EQUALIZE             40044
#define ID_FILTERS_GAMMACORRECT         40045
#define ID_FILTERS_NEGATIVE             40046
#define ID_FILTERS_NOISE                40047
#define ID_FILTERS_PIXELIZE             40048
#define ID_FILTERS_SHARPEN              40049
#define ID_EDIT_VIEWFACE                40050
#define ID_EDIT_VIEWBASEIMAGE           40051
#define ID_CONVERT_ALPHA                40052
#define ID_CONVERT_UNSIGNEDINT          40053
#define ID_EDIT_COPY40054               40054
#define ID_EDIT_PREVIOUSIMAGE           40055
#define ID_FILTERS_BLURGAUSSIAN         40064
#define ID_FILTERS_BLURAVERAGE          40065
#define ID_EDGEDETECT_SOBEL             40066
#define ID_EDGEDETECT_PREWITT           40067
#define ID_EDGEDETECT_EMBOSS            40068

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40069
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
