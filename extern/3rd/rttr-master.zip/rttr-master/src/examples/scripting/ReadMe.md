JSON Serialization
==================

This example demonstrate the usage of RTTR in order bind it to a scripting language.
For our purpose we are using chai script.

