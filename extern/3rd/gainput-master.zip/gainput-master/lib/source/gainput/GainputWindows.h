
#ifndef GAINPUTWINDOWS_H_
#define GAINPUTWINDOWS_H_

#define WIN32_LEAN_AND_MEAN

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <windows.h>
#include <Windowsx.h>
#ifdef DrawText
#undef DrawText
#endif

#endif
