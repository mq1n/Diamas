#pragma once

static const auto ip_address = "127.0.0.1";
static const auto port = 11111;
