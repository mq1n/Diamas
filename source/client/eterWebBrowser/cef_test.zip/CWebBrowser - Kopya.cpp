#include <windows.h>
#include <fstream>
#include "CefSimpleApp.h"
#include "SimpleHandler.h"
#include "CefApp.h"
#include "CefHandler.h"
#include "main_message_loop.h"
#include "main_message_loop_std.h"
#include "main_message_loop_external_pump.h"
#include "main_message_loop_multithreaded_win.h"

static std::string gs_stWebBrowserDefaultUrl = "http://www.google.com";
static std::string gs_stWebBrowserName = "WEBBROWSER";
static HINSTANCE gs_hInstance = nullptr;
static HWND gs_hWndWebBrowser = nullptr;
static HWND gs_hWndParent = nullptr;

static CefRefPtr <SimpleHandler> gs_pWebBrowserHandler;

void write(std::string t)
{
	std::ofstream of;
	of.open("test.txt", std::ios_base::app);
	if (!of.is_open() || !of.good())
		return;
	of << t << "\n";
	of.close();
}

int WebBrowser_Show(HWND hParent, const char* addr, const RECT* rc)
{
	int i = 0;
	write(std::to_string(i++));

	if (gs_hWndWebBrowser)
		return 0;

	gs_hWndParent = hParent;
	gs_pWebBrowserHandler = new SimpleHandler(false);
	write(std::to_string(i++));

	CefWindowInfo wi;
	wi.x = rc->left;
	wi.y = rc->top;
	wi.width = rc->right - rc->left;
	wi.height = rc->bottom - rc->top;
	wi.SetAsChild(gs_hWndParent, *rc);
	write(std::to_string(i++));

	CefBrowserSettings bs;
	if (!CefBrowserHost::CreateBrowserSync(wi, gs_pWebBrowserHandler, gs_stWebBrowserDefaultUrl, bs, nullptr, nullptr))
		return 0;
	write(std::to_string(i++));

	const auto browsers = gs_pWebBrowserHandler->GetBrowsers();
	if (browsers.begin() == browsers.end())
		return 0;
	const auto browser = browsers.begin()->get();

	if (browser && browser->GetHost())
		gs_hWndWebBrowser = browser->GetHost()->GetWindowHandle();
	write(std::to_string(i++));
	
	ShowWindow(gs_hWndWebBrowser, SW_SHOWNORMAL);
	UpdateWindow(gs_hWndWebBrowser);

	SetFocus(gs_hWndWebBrowser);
	

	return 1;
}

void WebBrowser_Move(const RECT* rc)
{
	if (!gs_hWndWebBrowser)
		return;

	MoveWindow(gs_hWndWebBrowser, rc->left, rc->top, rc->right - rc->left, rc->bottom - rc->top, 1);
}

void WebBrowser_Hide()
{
	if (!gs_hWndWebBrowser)
		return;

	ShowWindow(gs_hWndWebBrowser, SW_HIDE);

	if (IsWindow(gs_hWndWebBrowser))
		gs_pWebBrowserHandler->GetBrowsers().begin()->get()->GetHost()->CloseBrowser(true);

	SetFocus(gs_hWndParent);
}

int WebBrowser_IsVisible()
{
	return !!gs_hWndWebBrowser;
}

void WebBrowser_OnMessage()
{
	CefDoMessageLoopWork();
}
void WebBrowser_RunMessageLoop()
{
	CefRunMessageLoop();
}

VOID CALLBACK xdxd(HWND hwnd, UINT message, UINT_PTR iCurrTimerID, DWORD dwTime)
{
	WebBrowser_OnMessage();

}
DWORD WINAPI WebBrowserWorker(LPVOID)
{
	// Enable High-DPI support on Windows 7 or newer.
	CefEnableHighDPISupport();

	// Provide CEF with command-line arguments.
	auto hInstance = GetModuleHandleW(0);
	CefMainArgs main_args(hInstance);

	// Parse command-line arguments.
	CefRefPtr<CefCommandLine> command_line = CefCommandLine::CreateCommandLine();
	command_line->InitFromString(::GetCommandLineW());

	// SimpleApp implements application-level callbacks for the browser process.
	// It will create the first browser instance in OnContextInitialized() after
	// CEF has initialized.
	CefRefPtr <SimpleApp> app(new SimpleApp);

//	MessageBoxA(0, "1", 0, 0);
	// Execute the secondary process, if any.
	int exit_code = CefExecuteProcess(main_args, nullptr, nullptr);
	if (exit_code >= 0)
	{
		// The sub-process has completed so return here.
		return 0;
	}
	else
	{
		//scoped_ptr <client::MainMessageLoop> message_loop(new client::MainMessageLoopStd);
		//int result = message_loop->Run();
	}

//	MessageBoxA(0, "2", 0, 0);

	// Create the main message loop object.
//	scoped_ptr <client::MainMessageLoop> message_loop(new client::MainMessageLoopStd);
//	scoped_ptr <client::MainMessageLoop> message_loop = client::MainMessageLoopExternalPump::Create();
//	scoped_ptr <client::MainMessageLoop> message_loop(new client::MainMessageLoopMultithreadedWin);

	// Specify CEF global settings here.
	CefSettings settings;
	settings.no_sandbox = true;
	settings.multi_threaded_message_loop = false;
	settings.external_message_pump = true;
	settings.windowless_rendering_enabled = true;

	// Initialize CEF.
	if (!CefInitialize(main_args, settings, app, nullptr))
	{
		return 0;
	}
//	MessageBoxA(0, "3", 0, 0);

	const auto timerid=SetTimer(nullptr, 0, 15, xdxd);

//	int result = message_loop->Run();
//	MessageBoxA(0, "4", 0, 0);

	gs_hInstance = hInstance;
//	WebBrowser_RunMessageLoop();

	return 0;
}

int WebBrowser_SubProcessStartup(HINSTANCE hInstance)
{
	MessageBoxA(0, "sub", 0, 0);

	CefMainArgs main_args(hInstance);
	int exit_code = CefExecuteProcess(main_args, nullptr, nullptr);
	if (exit_code >= 0)
	{
		// The sub-process has completed so return here.
		MessageBoxA(0, "rip", 0, 0);
		return 0;
	}
	else
	{
		MessageBoxA(0, "abv", 0, 0);
		scoped_ptr <client::MainMessageLoop> message_loop(new client::MainMessageLoopStd);
		int result = message_loop->Run();
	}
}

int WebBrowser_Startup(HINSTANCE hInstance)
{
//	CreateThread(0, 0, WebBrowserWorker, 0, 0, 0);
	WebBrowserWorker(0);
	return 1;
}

void WebBrowser_Cleanup()
{
//	if (gs_hInstance)
//		UnregisterClass(gs_stWebBrowserName.c_str(), gs_hInstance);
}

void WebBrowser_Destroy()
{
	WebBrowser_Hide();
	
	// Shut down CEF.
	CefShutdown();
}
