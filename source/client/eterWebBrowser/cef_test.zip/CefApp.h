#pragma once

#include "include/cef_app.h"

// CefApp does all of the work, but it is an abstract base class that needs reference counting implemented;
// thus, we create a dummy class that inherits off of CefApp but does nothing
class MyCefApp : public CefApp
{
public:
    MyCefApp()
    {
    }
    virtual ~MyCefApp()
    {
    }

private:
    IMPLEMENT_REFCOUNTING(MyCefApp);
};