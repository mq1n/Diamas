#include <windows.h>
#include <fstream>
#include "CefSimpleApp.h"
#include "SimpleHandler.h"
#include "CefApp.h"
#include "CefHandler.h"
#include "main_message_loop.h"
#include "main_message_loop_std.h"
#include "main_message_loop_external_pump.h"
#include "main_message_loop_multithreaded_win.h"

static std::string gs_stWebBrowserDefaultUrl = "http://www.google.com";
static std::string gs_stWebBrowserName = "WEBBROWSER";
static HINSTANCE gs_hInstance = nullptr;
static HWND gs_hWndWebBrowser = nullptr;
static HWND gs_hWndParent = nullptr;

static CefRefPtr <CefHandler> gs_pWebBrowserHandler;

void write(std::string t)
{
	std::ofstream of;
	of.open("test.txt", std::ios_base::app);
	if (!of.is_open() || !of.good())
		return;
	of << t << "\n";
	of.close();
}

LRESULT CALLBACK BrowserWindowWndProc(HWND window_handle, UINT message, WPARAM w_param, LPARAM l_param)
{
	LRESULT result(0);
	switch (message)
	{
	case WM_CREATE:
	{
		gs_pWebBrowserHandler = new CefHandler();

		RECT rect = { 0 };
		GetClientRect(window_handle, &rect);

		CefWindowInfo info;
		info.SetAsChild(window_handle, rect);

		CefBrowserSettings settings;
		if (CefBrowserHost::CreateBrowser(info, gs_pWebBrowserHandler.get(),
			CefString("http://www.google.com"), settings, NULL, NULL))
			write("creating browser sucess!");
	}
	break;

	case WM_SIZE:
	{
		// from the cefclient example, do not allow the window to be resized to 0x0 or the layout will break;
		// also be aware that if the size gets too small, GPU acceleration disables
		if ((w_param != SIZE_MINIMIZED)
			&& (gs_pWebBrowserHandler.get())
			&& (gs_pWebBrowserHandler->GetBrowser()))
		{
			CefWindowHandle hwnd(gs_pWebBrowserHandler->GetBrowser()->GetHost()->GetWindowHandle());
			if (hwnd)
			{
				RECT rect = { 0 };
				GetClientRect(window_handle, &rect);
				HDWP hdwp = BeginDeferWindowPos(1);
				hdwp = DeferWindowPos(hdwp, hwnd, NULL, rect.left,
					rect.top, rect.right - rect.left, rect.bottom - rect.top, SWP_NOZORDER);
				EndDeferWindowPos(hdwp);
			}
		}
	}
	break;

	case WM_ERASEBKGND:
	{
		if ((gs_pWebBrowserHandler.get())
			&& (gs_pWebBrowserHandler->GetBrowser()))
		{
			CefWindowHandle hwnd(gs_pWebBrowserHandler->GetBrowser()->GetHost()->GetWindowHandle());
			// from the cefclient example, don't erase the background 
			// if the browser window has been loaded to avoid flashing
			result = hwnd ? 1 : DefWindowProc(window_handle, message, w_param, l_param);
		}
	}
	break;

	case WM_ENTERMENULOOP:
	{
		if (!w_param)
		{
			CefSetOSModalLoop(true);
		}
		result = DefWindowProc(window_handle, message, w_param, l_param);
	}
	break;

	case WM_EXITMENULOOP:
	{
		if (!w_param)
		{
			CefSetOSModalLoop(false);
		}
		result = DefWindowProc(window_handle, message, w_param, l_param);
	}
	break;

	case WM_DESTROY:
		break;

	default:
	{
		result = DefWindowProc(window_handle, message, w_param, l_param);
	}
	break;
	}
	return result;
}

int WebBrowser_Show(HWND hParent, const char* addr, const RECT* rc)
{
	if (gs_hWndWebBrowser)
		return 0;

	gs_hWndParent = hParent;
	gs_hWndWebBrowser = CreateWindowEx(0, gs_stWebBrowserName.c_str(), gs_stWebBrowserName.c_str(), WS_CHILD | WS_VISIBLE,
		rc->left, rc->top, (rc->right - rc->left), (rc->bottom - rc->top), hParent, NULL, gs_hInstance, NULL);

	if (!gs_hWndWebBrowser)
		return 0;

	write("Show is getting executed.");

	CefMainArgs main_args(gs_hInstance);

	CefRefPtr <SimpleApp> app(new SimpleApp());

	CefSettings settings;
	settings.no_sandbox = true;

	if (CefExecuteProcess(main_args, app.get(), NULL) == -1)
	{
		CefInitialize(main_args, settings, app.get(), NULL);
		write("executing cef process.");
	}

	ShowWindow(gs_hWndWebBrowser, SW_SHOWNORMAL);
	UpdateWindow(gs_hWndWebBrowser);

	SetFocus(gs_hWndWebBrowser);
	
	return 1;
}

void WebBrowser_Move(const RECT* rc)
{
	if (!gs_hWndWebBrowser)
		return;

	MoveWindow(gs_hWndWebBrowser, rc->left, rc->top, rc->right - rc->left, rc->bottom - rc->top, 1);
}

void WebBrowser_Hide()
{
	if (!gs_hWndWebBrowser)
		return;

	ShowWindow(gs_hWndWebBrowser, SW_HIDE);

	if (IsWindow(gs_hWndWebBrowser))
		DestroyWindow(gs_hWndWebBrowser);
	gs_hWndWebBrowser = nullptr;

	SetFocus(gs_hWndParent);
}

int WebBrowser_IsVisible()
{
	return !!gs_hWndWebBrowser;
}

int WebBrowser_Startup(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;
	ZeroMemory(&wcex, sizeof(WNDCLASSEX));
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.hbrBackground = WHITE_BRUSH;
	wcex.hInstance = hInstance;
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.lpfnWndProc = BrowserWindowWndProc;
	wcex.lpszClassName = gs_stWebBrowserName.c_str();
	RegisterClassEx(&wcex);

	gs_hInstance = hInstance;
	return 1;
}

void WebBrowser_Cleanup()
{
	if (gs_hInstance)
		UnregisterClass(gs_stWebBrowserName.c_str(), gs_hInstance);

	// Shut down CEF.
	CefShutdown();
}

void WebBrowser_Destroy()
{
	WebBrowser_Hide();
}
